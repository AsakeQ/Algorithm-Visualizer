let array = [];
let sorting = false;

function generateArray() {
  const size = document.getElementById("sizeSlider").value;
  array = Array.from({length: size}, () => Math.floor(Math.random() * 100) + 1);
  renderArray();
}

function renderArray(activeIndices = []) {
  const arrayContainer = document.getElementById("array");
  arrayContainer.innerHTML = "";
  const maxVal = Math.max(...array);

  array.forEach((val, i) => {
    const bar = document.createElement("div");
    bar.classList.add("bar");
    bar.style.height = `${(val / maxVal) * 100}%`;
    if (activeIndices.includes(i)) {
      bar.classList.add("active");
    }
    arrayContainer.appendChild(bar);
  });
}

async function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function startSort(type) {
  if (sorting) return;
  sorting = true;

  const descriptions = {
    bubble: "🔵 Пузырьковая сортировка — самый простой алгоритм, сравнивает пары и меняет их местами.",
    quick: "⚡ Быстрая сортировка — использует принцип 'разделяй и властвуй'.",
    insertion: "🃏 Сортировка вставками — как сортировка карт в руке.",
    shell: "🐚 Сортировка Шелла — улучшенная версия вставками с разными шагами.",
    heap: "⛰ Пирамидальная сортировка — использует структуру данных 'куча'.",
    counting: "🔢 Сортировка подсчётом — быстрая не сравнительная сортировка."
  };
  document.getElementById("description").innerText = descriptions[type];

  switch (type) {
    case "bubble": await bubbleSort(); break;
    case "quick": await quickSort(0, array.length - 1); break;
    case "insertion": await insertionSort(); break;
    case "shell": await shellSort(); break;
    case "heap": await heapSort(); break;
    case "counting": await countingSort(); break;
  }

  sorting = false;
}

// ---------- Алгоритмы ----------

async function bubbleSort() {
  let n = array.length;
  for (let i = 0; i < n; i++) {
    for (let j = 0; j < n - i - 1; j++) {
      if (array[j] > array[j+1]) {
        [array[j], array[j+1]] = [array[j+1], array[j]];
        renderArray([j, j+1]);
        await sleep(getSpeed());
      }
    }
  }
}

async function quickSort(low, high) {
  if (low < high) {
    let pi = await partition(low, high);
    await quickSort(low, pi - 1);
    await quickSort(pi + 1, high);
  }
}
async function partition(low, high) {
  let pivot = array[high];
  let i = low - 1;
  for (let j = low; j < high; j++) {
    if (array[j] < pivot) {
      i++;
      [array[i], array[j]] = [array[j], array[i]];
      renderArray([i, j, high]);
      await sleep(getSpeed());
    }
  }
  [array[i+1], array[high]] = [array[high], array[i+1]];
  renderArray([i+1, high]);
  await sleep(getSpeed());
  return i + 1;
}

async function insertionSort() {
  for (let i = 1; i < array.length; i++) {
    let key = array[i];
    let j = i - 1;
    while (j >= 0 && array[j] > key) {
      array[j+1] = array[j];
      j--;
      renderArray([j+1, i]);
      await sleep(getSpeed());
    }
    array[j+1] = key;
    renderArray([j+1, i]);
    await sleep(getSpeed());
  }
}

async function shellSort() {
  let n = array.length;
  for (let gap = Math.floor(n/2); gap > 0; gap = Math.floor(gap/2)) {
    for (let i = gap; i < n; i++) {
      let temp = array[i];
      let j;
      for (j = i; j >= gap && array[j-gap] > temp; j -= gap) {
        array[j] = array[j-gap];
        renderArray([j, j-gap]);
        await sleep(getSpeed());
      }
      array[j] = temp;
      renderArray([j, i]);
      await sleep(getSpeed());
    }
  }
}

async function heapSort() {
  let n = array.length;
  for (let i = Math.floor(n/2) - 1; i >= 0; i--) {
    await heapify(n, i);
  }
  for (let i = n-1; i > 0; i--) {
    [array[0], array[i]] = [array[i], array[0]];
    renderArray([0, i]);
    await sleep(getSpeed());
    await heapify(i, 0);
  }
}
async function heapify(n, i) {
  let largest = i;
  let l = 2*i + 1;
  let r = 2*i + 2;

  if (l < n && array[l] > array[largest]) largest = l;
  if (r < n && array[r] > array[largest]) largest = r;

  if (largest != i) {
    [array[i], array[largest]] = [array[largest], array[i]];
    renderArray([i, largest]);
    await sleep(getSpeed());
    await heapify(n, largest);
  }
}

async function countingSort() {
  let max = Math.max(...array);
  let min = Math.min(...array);
  let range = max - min + 1;
  let count = Array(range).fill(0);
  let output = Array(array.length).fill(0);

  for (let i = 0; i < array.length; i++) {
    count[array[i] - min]++;
    renderArray([i]);
    await sleep(getSpeed());
  }

  for (let i = 1; i < count.length; i++) {
    count[i] += count[i-1];
  }

  for (let i = array.length - 1; i >= 0; i--) {
    output[count[array[i] - min] - 1] = array[i];
    count[array[i] - min]--;
    renderArray([i]);
    await sleep(getSpeed());
  }

  for (let i = 0; i < array.length; i++) {
    array[i] = output[i];
    renderArray([i]);
    await sleep(getSpeed());
  }
}

// Скорость из слайдера
function getSpeed() {
  return document.getElementById("speedSlider").value;
}

// При загрузке
generateArray();
